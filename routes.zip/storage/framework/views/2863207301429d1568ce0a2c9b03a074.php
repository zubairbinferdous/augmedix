
<?php $__env->startSection('main_content'); ?>
    <div class="main-content">
        <div class="row">
            <div class="col-12">
                <div class="card mb-30">
                    <div class="card-body">
                        <div class="d-sm-flex justify-content-between align-items-center">
                            <h4 class="font-20">portfolio</h4>

                            <div class="d-flex flex-wrap">
                                <!-- Date Picker -->
                                
                                <!-- End Date Picker -->


                                <!-- Dropdown Button -->
                                <div class="dropdown-button mt-3 mt-sm-0">
                                    <a href="<?php echo e(route('addTread')); ?>" class="details-btn"> Add Your Tread <i
                                            class="icofont-arrow-right"></i></a></td>
                                </div>
                                

                                <!-- End Dropdown Button -->
                            </div>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <!-- Invoice List Table -->
                        <table class="text-nowrap dh-table">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Unite</th>
                                    <th>Open</th>
                                    <th>Amount</th>
                                    <th>Current</th>
                                    <th>Value</th>
                                    <th>P/L</th>
                                    <th>P/L %</th>


                                </tr>
                            </thead>
                            <tbody>

                                <?php
                                    $current = 90;
                                ?>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item->TreadName); ?></td>
                                        <td><?php echo e($item->Unite); ?></td>
                                        <td><?php echo e($item->Open); ?></td>
                                        <td><?php echo e($item->Unite * $item->Open); ?></td>
                                        <td> <?php echo e($current); ?> </td>
                                        <td><?php echo e($item->Unite * $current); ?></td>
                                        <td><?php echo e($item->Unite * $current - $item->Unite * $item->Open); ?></td>
                                        <td>-</td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                            </tbody>
                        </table>
                        <!-- End Invoice List Table -->
                    </div>
                </div>

            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\augmedix\resources\views/frontend/portfolio.blade.php ENDPATH**/ ?>