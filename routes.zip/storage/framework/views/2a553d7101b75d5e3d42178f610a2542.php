
<?php $__env->startSection('main_content'); ?>
    <div class="main-content">
        <div class="container-fluid">
            <div class="row">

                <div class="col-lg-12">
                    <!-- Base Horizontal Form With Icons -->
                    <div class="form-element py-30 multiple-column">
                        

                        <!-- Form -->
                        <form method="POST" action="<?php echo e(route('add.tread.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-lg-4">
                                    <!-- Form Group -->
                                    <div class="form-group">
                                        <label class="font-14 bold mb-2">Name</label>
                                        <input type="text" name="name_tread" class="theme-input-style"
                                            placeholder="Name">
                                    </div>
                                </div>
                                
                                <div class="col-lg-4">
                                    <!-- Form Group -->
                                    <div class="form-group">
                                        <label class="font-14 bold mb-2">Unite</label>
                                        <input type="number" name="unite_tread" class="theme-input-style"
                                            placeholder="Unite">
                                    </div>
                                    <!-- End Form Group -->


                                </div>
                                <div class="col-lg-4">
                                    <!-- Form Group -->
                                    <div class="form-group">
                                        <label class="font-14 bold mb-2">Open</label>
                                        <input type="number" name="open_tread" class="theme-input-style"
                                            placeholder="Open">
                                    </div>
                                    <!-- End Form Group -->
                                </div>

                            </div>

                            <!-- Form Row -->
                            <div class="form-group pt-1">
                                
                            </div>
                            <!-- End Form Row -->

                            <!-- Form Row -->
                            <div class="form-row">
                                <div class="col-12 text-right">
                                    <button type="submit" class="btn long">ADD
                                        DATA</button>
                                </div>
                            </div>
                            <!-- End Form Row -->
                        </form>
                        <!-- End Form -->
                    </div>
                    <!-- End Horizontal Form With Icons -->
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\augmedix\resources\views/frontend/addTread.blade.php ENDPATH**/ ?>