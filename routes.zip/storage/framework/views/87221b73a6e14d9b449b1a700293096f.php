<?php $__env->startSection('main_content'); ?>
    <!-- Main Content -->



    <div class="main-content">
        <div class="container-fluid">
            <div class="row slider">
                <div class="col-xl-2 col-md-12 col-sm-6">
                    <!-- Card -->
                    <div class="card area-chart-box mb-30">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div class="">
                                    <h4 class="mb-1">Income</h4>
                                    <p class="font-14 c3">Increase in Average</p>
                                </div>
                                <div class="">
                                    <h2>50<sup>%</sup></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Card -->
                </div>

                <div class="col-xl-2 col-md-12 col-sm-6">
                    <!-- Card -->
                    <div class="card area-chart-box mb-30">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div class="">
                                    <h4 class="mb-1">Income</h4>
                                    <p class="font-14 c3">Increase in Average</p>
                                </div>
                                <div class="">
                                    <h2>50<sup>%</sup></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Card -->
                </div>

                <div class="col-xl-2 col-md-12 col-sm-6">
                    <!-- Card -->
                    <div class="card area-chart-box mb-30">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div class="">
                                    <h4 class="mb-1">Income</h4>
                                    <p class="font-14 c3">Increase in Average</p>
                                </div>
                                <div class="">
                                    <h2>50<sup>%</sup></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Card -->
                </div>


                <div class="col-xl-2 col-md-12 col-sm-6">
                    <!-- Card -->
                    <div class="card area-chart-box mb-30">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div class="">
                                    <h4 class="mb-1">Income</h4>
                                    <p class="font-14 c3">Increase in Average</p>
                                </div>
                                <div class="">
                                    <h2>50<sup>%</sup></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Card -->
                </div>


                <div class="col-xl-2 col-md-12 col-sm-6">
                    <!-- Card -->
                    <div class="card area-chart-box mb-30">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div class="">
                                    <h4 class="mb-1">Income</h4>
                                    <p class="font-14 c3">Increase in Average</p>
                                </div>
                                <div class="">
                                    <h2>50<sup>%</sup></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Card -->
                </div>


                <div class="col-xl-2 col-md-12 col-sm-6">
                    <!-- Card -->
                    <div class="card area-chart-box mb-30">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div class="">
                                    <h4 class="mb-1">Income</h4>
                                    <p class="font-14 c3">Increase in Average</p>
                                </div>
                                <div class="">
                                    <h2>50<sup>%</sup></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Card -->
                </div>


                <div class="col-xl-2 col-md-12 col-sm-6">
                    <!-- Card -->
                    <div class="card area-chart-box mb-30">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div class="">
                                    <h4 class="mb-1">Income</h4>
                                    <p class="font-14 c3">Increase in Average</p>
                                </div>
                                <div class="">
                                    <h2>50<sup>%</sup></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Card -->
                </div>


                <div class="col-xl-2 col-md-12 col-sm-6">
                    <!-- Card -->
                    <div class="card area-chart-box mb-30">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div class="">
                                    <h4 class="mb-1">Income</h4>
                                    <p class="font-14 c3">Increase in Average</p>
                                </div>
                                <div class="">
                                    <h2>50<sup>%</sup></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Card -->
                </div>


                <div class="col-xl-2 col-md-12 col-sm-6">
                    <!-- Card -->
                    <div class="card area-chart-box mb-30">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div class="">
                                    <h4 class="mb-1">Income</h4>
                                    <p class="font-14 c3">Increase in Average</p>
                                </div>
                                <div class="">
                                    <h2>50<sup>%</sup></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Card -->
                </div>



            </div>

            <div class="row" style="height: 800px; padding:20px">
                <!-- TradingView Widget BEGIN -->
                <div class="tradingview-widget-container" style="height:100%;width:100%">
                    <div id="tradingview_8c43b" style="height:calc(100% - 32px);width:100%"></div>
                    
                    <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
                    <script type="text/javascript">
                        new TradingView.widget({
                            "autosize": true,
                            "symbol": "NASDAQ:AAPL",
                            "interval": "1",
                            "timezone": "Etc/UTC",
                            "theme": "dark",
                            "style": "1",
                            "locale": "en",
                            "enable_publishing": true,
                            "withdateranges": true,
                            "hide_side_toolbar": false,
                            "allow_symbol_change": true,
                            "details": true,
                            "hotlist": true,
                            "calendar": true,
                            "container_id": "tradingview_8c43b"
                        });
                    </script>
                </div>
                <!-- TradingView Widget END -->
            </div>
            <div class="row">
                <div class="col-xl-4 col-md-8">
                    <!-- Card -->
                    
                    <!-- End Card -->
                </div>

                
            </div>
            
        </div>
    </div>


    <!-- End Main Content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\augmedix\resources\views/dashboard.blade.php ENDPATH**/ ?>