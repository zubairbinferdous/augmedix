<!DOCTYPE html>
<html lang="zxx">

<head>
    <!-- Page Title -->
    <title>Audmedix</title>

    <!-- Meta Data -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="keywords" content="">

    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('/fontend/assets/img/favicon.png')); ?>">

    <!-- Web Fonts -->
    <link href="https://fonts.googleapis.com/css?family=PT+Sans:400,400i,700,700i&display=swap" rel="stylesheet">

    <!-- ======= BEGIN GLOBAL MANDATORY STYLES ======= -->
    <link rel="stylesheet" href="<?php echo e(asset('fontend/assets/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('fontend/assets/fonts/icofont/icofont.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('fontend/assets/plugins/perfect-scrollbar/perfect-scrollbar.min.css')); ?>">
    <!-- ======= END BEGIN GLOBAL MANDATORY STYLES ======= -->

    <!-- ======= BEGIN PAGE LEVEL PLUGINS STYLES ======= -->
    <link rel="stylesheet" href="<?php echo e(asset('fontend/assets/plugins/apex/apexcharts.css')); ?>">
    <!-- ======= END BEGIN PAGE LEVEL PLUGINS STYLES ======= -->

    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css"
        integrity="sha512-17EgCFERpgZKcm0j0fEq1YCJuyAWdz9KUtv1EjVuaOz8pDnh/0nZxmU6BBXwaaxqoi9PQXnRWqlcDB027hgv9A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css"
        integrity="sha512-yHknP1/AwR+yx26cB1y0cjvQUMvEa2PFzt1c9LlS4pRQ5NOTZFWbhBig+X9G9eYW/8m0/4OXNx8pxJ6z57x0dw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <!-- ======= MAIN STYLES ======= -->
    <link rel="stylesheet" href="<?php echo e(asset('fontend/assets/css/style.css')); ?>">
    <!-- ======= END MAIN STYLES ======= -->
</head>

<body>

    <!-- Offcanval Overlay -->
    <div class="offcanvas-overlay"></div>
    <!-- Offcanval Overlay -->

    <!-- Wrapper -->
    <div class="wrapper">

        <!-- Header -->
        <header class="header fixed-top d-flex align-content-center flex-wrap">
            <!-- Logo -->
            <div class="logo">
                <h2>Audmedix </h2>
            </div>
            <!-- End Logo -->

            <!-- Main Header -->
            <div class="main-header">
                <div class="container-fluid">
                    <div class="row justify-content-between">
                        <div class="col-3 col-lg-1 col-xl-4">
                            <!-- Header Left -->
                            <div class="main-header-left h-100 d-flex align-items-center">
                                <!-- Main Header User -->
                                <div class="main-header-user">
                                    <a href="#" class="d-flex align-items-center" data-toggle="dropdown">
                                        <div class="menu-icon">
                                            <span></span>
                                            <span></span>
                                            <span></span>
                                        </div>

                                        <div class="user-profile d-xl-flex align-items-center d-none">
                                            <!-- User Avatar -->
                                            <div class="user-avatar">
                                                <img src="<?php echo e(asset('fontend/assets/img/avatar/user.png')); ?>"
                                                    alt="">
                                            </div>
                                            <!-- End User Avatar -->

                                            <!-- User Info -->
                                            <div class="user-info">
                                                <h4 class="user-name"><?php echo e(Auth::user()->name); ?></h4>
                                                <p class="user-email"><?php echo e(Auth::user()->email); ?></p>
                                            </div>
                                            <!-- End User Info -->
                                        </div>
                                    </a>
                                    <div class="dropdown-menu">
                                        <a href="#">My Profile</a>
                                        <a href="#">task</a>
                                        <a href="#">Settings</a>
                                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="logout">logout</button>
                                        </form>
                                    </div>
                                </div>
                                <!-- End Main Header User -->

                                <!-- Main Header Menu -->
                                <div class="main-header-menu d-block d-lg-none">
                                    <div class="header-toogle-menu">
                                        <i class="icofont-navigation-menu"></i>
                                        <img src="assets/img/menu.png" alt="">
                                    </div>
                                </div>
                                <!-- End Main Header Menu -->
                            </div>
                            <!-- End Header Left -->
                        </div>
                        <div class="col-9 col-lg-11 col-xl-8">
                            <!-- Header Right -->
                            <div class="main-header-right d-flex justify-content-end">
                                <ul class="nav">
                                    <li class="ml-0">
                                        <!-- Main Header Language -->
                                        <div class="main-header-language">
                                            <a href="#" data-toggle="dropdown">
                                                <img src="assets/img/svg/globe-icon.svg" alt="">
                                            </a>
                                            <div class="dropdown-menu style--three">
                                                <a href="#">
                                                    <span><img src="assets/img/usa.png" alt=""></span>
                                                    USA
                                                </a>
                                                <a href="#">
                                                    <span><img src="assets/img/china.png" alt=""></span>
                                                    China
                                                </a>
                                                <a href="#">
                                                    <span><img src="assets/img/russia.png" alt=""></span>
                                                    Russia
                                                </a>
                                                <a href="#">
                                                    <span><img src="assets/img/spain.png" alt=""></span>
                                                    Spain
                                                </a>
                                                <a href="#">
                                                    <span><img src="assets/img/brazil.png" alt=""></span>
                                                    Brazil
                                                </a>
                                                <a href="#">
                                                    <span><img src="assets/img/france.png" alt=""></span>
                                                    France
                                                </a>
                                                <a href="#">
                                                    <span><img src="assets/img/algeria.png" alt=""></span>
                                                    Algeria
                                                </a>
                                            </div>
                                        </div>
                                        <!-- End Main Header Language -->
                                    </li>
                                    <li class="ml-0 d-none d-lg-flex">
                                        <!-- Main Header Print -->
                                        <div class="main-header-print">
                                            <a href="#">
                                                <img src="assets/img/svg/print-icon.svg" alt="">
                                            </a>
                                        </div>
                                        <!-- End Main Header Print -->
                                    </li>
                                    <li class="d-none d-lg-flex">
                                        <!-- Main Header Time -->
                                        <div class="main-header-date-time text-right">
                                            <h3 class="time">
                                                <span id="hours">21</span>
                                                <span id="point">:</span>
                                                <span id="min">06</span>
                                            </h3>
                                            <span class="date"><span id="date">Tue, 12 October
                                                    2019</span></span>
                                        </div>
                                        <!-- End Main Header Time -->
                                    </li>
                                    <li class="d-none d-lg-flex">
                                        <!-- Main Header Button -->
                                        
                                        <!-- End Main Header Button -->
                                    </li>
                                    <li class="order-2 order-sm-0">
                                        <!-- Main Header Search -->
                                        <div class="main-header-search">
                                            <form action="#" class="search-form">
                                                <div class="theme-input-group header-search">
                                                    <input type="text" class="theme-input-style"
                                                        placeholder="Search Here">

                                                    <button type="submit"><img
                                                            src="<?php echo e(asset('fontend/assets/img/svg/search-icon.svg')); ?>"
                                                            alt="" class="svg"></button>
                                                </div>
                                            </form>
                                        </div>
                                        <!-- End Main Header Search -->
                                    </li>
                                    <li>
                                        <!-- Main Header Messages -->
                                        <div class="main-header-message">
                                            
                                            <!-- End Item Single -->
                                        </div>
                                        <!-- End Dropdown Body -->
                            </div>
                        </div>
                        <!-- End Main Header Notification -->
                        </li>
                        </ul>
                    </div>
                    <!-- End Header Right -->
                </div>
            </div>
    </div>
    </div>
    <!-- End Main Header -->
    </header>
    <!-- End Header -->
    <div class="main-wrapper">
        <!-- Sidebar -->
        <nav class="sidebar" data-trigger="scrollbar">
            <!-- Sidebar Header -->
            <div class="sidebar-header d-none d-lg-block">
                <!-- Sidebar Toggle Pin Button -->
                <div class="sidebar-toogle-pin">
                    <i class="icofont-tack-pin"></i>
                </div>
                <!-- End Sidebar Toggle Pin Button -->
            </div>
            <!-- End Sidebar Header -->

            <!-- Sidebar Body -->
            <div class="sidebar-body">
                <!-- Nav -->
                <ul class="nav">
                    <li class="nav-category">Main</li>
                    <li class="active">
                        <a href="<?php echo e(route('dashboard')); ?>">
                            <i class="icofont-pie-chart"></i>
                            <span class="link-title">Home</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('watch')); ?>">
                            <i class="icofont-shopping-cart"></i>
                            <span class="link-title">Watchlist</span>
                        </a>

                        <!-- Sub Menu -->
                        
                        <!-- End Sub Menu -->
                    </li>
                    <li>
                        <a href="<?php echo e(route('portfolio')); ?>">
                            <i class="icofont-chart-histogram"></i>
                            <span class="link-title">Portfolio</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('discover')); ?>">
                            <i class="icofont-chart-histogram"></i>
                            <span class="link-title">Discover</span>
                        </a>
                    </li>
                    
                    

                    <!-- Sub Menu -->
                    
                </ul>
                <!-- End Nav -->
            </div>
            <!-- End Sidebar Body -->
        </nav>
        <!-- End Sidebar -->
        <!-- Main Wrapper -->
        <?php echo $__env->yieldContent('main_content'); ?>

        <!-- End Main Content -->
    </div>


    <!-- End Main Wrapper -->



    <!-- Footer -->
    <footer class="footer">
        
    </footer>
    <!-- End Footer -->
    </div>
    <!-- End wrapper -->

    <!-- ======= BEGIN GLOBAL MANDATORY SCRIPTS ======= -->
    
    <script type="text/javascript" src="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>

    <script src="<?php echo e(asset('fontend/assets/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('fontend/assets/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('fontend/assets/plugins/perfect-scrollbar/perfect-scrollbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('fontend/assets/js/script.js')); ?>"></script>
    <!-- ======= BEGIN GLOBAL MANDATORY SCRIPTS ======= -->

    <!-- ======= BEGIN PAGE LEVEL PLUGINS/CUSTOM SCRIPTS ======= -->
    <script src="<?php echo e(asset('fontend/assets/plugins/apex/apexcharts.min.js')); ?>"></script>
    <script src="<?php echo e(asset('fontend/assets/plugins/apex/custom-apexcharts.js')); ?>"></script>
    <!-- ======= End BEGIN PAGE LEVEL PLUGINS/CUSTOM SCRIPTS ======= -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"
        integrity="sha512-XtmMtDEcNz2j7ekrtHvOVR4iwwaD6o/FUJe6+Zq+HgcCsk3kj4uSQQR8weQ2QVj1o0Pk6PwYLohm206ZzNfubg=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script>
        $('.slider').slick({
            dots: true,
            infinite: true,
            speed: 300,
            slidesToShow: 6,
            slidesToScroll: 1,
            autoplay: true,
            autoplaySpeed: 500,
            responsive: [{
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 3,
                        infinite: true,
                        dots: true
                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 2
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1
                    }
                }
                // You can unslick at a given breakpoint now by adding:
                // settings: "unslick"
                // instead of a settings object
            ]
        });
    </script>
</body>

</html>
<?php /**PATH E:\laragon\www\augmedix\resources\views/welcome.blade.php ENDPATH**/ ?>