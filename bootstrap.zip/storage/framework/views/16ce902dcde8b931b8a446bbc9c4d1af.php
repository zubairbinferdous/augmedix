
<?php $__env->startSection('main_content'); ?>
    <div class="main-content">
        <div class="row">
            <div class="data" style="padding:30px">
                <h1>this is watch list page</h1>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eum quae unde velit voluptatem iste nihil
                    doloribus
                    vitae corrupti, quisquam sed vel ullam expedita praesentium, molestias quia quasi in itaque illo
                    blanditiis
                    laboriosam! Voluptate illum non nesciunt, facere dolorem officiis quas. Possimus natus ducimus provident
                    dicta veniam? Perferendis, nam fugit! Officiis reiciendis commodi corrupti asperiores non id nobis.
                    Omnis
                    corrupti quidem porro repellendus rem fugiat est minima! Fugit vero obcaecati at debitis! Repellat
                    exercitationem culpa ullam saepe, hic ab. Laboriosam quibusdam porro sunt neque, odio voluptates ad
                    repellat
                    nemo magni cupiditate. Dolorem cupiditate ex molestiae facilis hic, eligendi ullam! Mollitia, sit.</p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\augmedix\resources\views/frontend/watch.blade.php ENDPATH**/ ?>