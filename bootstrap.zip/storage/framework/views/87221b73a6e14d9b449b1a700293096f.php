<?php $__env->startSection('main_content'); ?>
    <!-- Main Content -->



    <div class="main-content">
        <div class="container-fluid">
            <div class="row slider">
                <div class="col-xl-2 col-md-12 col-sm-6">
                    <!-- Card -->
                    <div class="card area-chart-box mb-30">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div class="">
                                    <h4 class="mb-1">Income</h4>
                                    <p class="font-14 c3">Increase in Average</p>
                                </div>
                                <div class="">
                                    <h2>50<sup>%</sup></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Card -->
                </div>

                <div class="col-xl-2 col-md-12 col-sm-6">
                    <!-- Card -->
                    <div class="card area-chart-box mb-30">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div class="">
                                    <h4 class="mb-1">Income</h4>
                                    <p class="font-14 c3">Increase in Average</p>
                                </div>
                                <div class="">
                                    <h2>50<sup>%</sup></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Card -->
                </div>

                <div class="col-xl-2 col-md-12 col-sm-6">
                    <!-- Card -->
                    <div class="card area-chart-box mb-30">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div class="">
                                    <h4 class="mb-1">Income</h4>
                                    <p class="font-14 c3">Increase in Average</p>
                                </div>
                                <div class="">
                                    <h2>50<sup>%</sup></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Card -->
                </div>


                <div class="col-xl-2 col-md-12 col-sm-6">
                    <!-- Card -->
                    <div class="card area-chart-box mb-30">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div class="">
                                    <h4 class="mb-1">Income</h4>
                                    <p class="font-14 c3">Increase in Average</p>
                                </div>
                                <div class="">
                                    <h2>50<sup>%</sup></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Card -->
                </div>


                <div class="col-xl-2 col-md-12 col-sm-6">
                    <!-- Card -->
                    <div class="card area-chart-box mb-30">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div class="">
                                    <h4 class="mb-1">Income</h4>
                                    <p class="font-14 c3">Increase in Average</p>
                                </div>
                                <div class="">
                                    <h2>50<sup>%</sup></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Card -->
                </div>


                <div class="col-xl-2 col-md-12 col-sm-6">
                    <!-- Card -->
                    <div class="card area-chart-box mb-30">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div class="">
                                    <h4 class="mb-1">Income</h4>
                                    <p class="font-14 c3">Increase in Average</p>
                                </div>
                                <div class="">
                                    <h2>50<sup>%</sup></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Card -->
                </div>


                <div class="col-xl-2 col-md-12 col-sm-6">
                    <!-- Card -->
                    <div class="card area-chart-box mb-30">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div class="">
                                    <h4 class="mb-1">Income</h4>
                                    <p class="font-14 c3">Increase in Average</p>
                                </div>
                                <div class="">
                                    <h2>50<sup>%</sup></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Card -->
                </div>


                <div class="col-xl-2 col-md-12 col-sm-6">
                    <!-- Card -->
                    <div class="card area-chart-box mb-30">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div class="">
                                    <h4 class="mb-1">Income</h4>
                                    <p class="font-14 c3">Increase in Average</p>
                                </div>
                                <div class="">
                                    <h2>50<sup>%</sup></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Card -->
                </div>


                <div class="col-xl-2 col-md-12 col-sm-6">
                    <!-- Card -->
                    <div class="card area-chart-box mb-30">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div class="">
                                    <h4 class="mb-1">Income</h4>
                                    <p class="font-14 c3">Increase in Average</p>
                                </div>
                                <div class="">
                                    <h2>50<sup>%</sup></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Card -->
                </div>



            </div>
            <div class="row">
                <div class="col-xl-4 col-md-8">
                    <!-- Card -->
                    <div class="card mb-30">
                        <div class="card-body">
                            <div class="d-flex align-items-center justify-content-between">
                                <div class="increase">
                                    <div class="card-title d-flex align-items-end mb-2">
                                        <h2>86<sup>%</sup></h2>
                                        <p class="font-14">Increased</p>
                                    </div>
                                    <h3 class="card-subtitle mb-2">Congratulation!</h3>
                                    <p class="font-16">You've finished all of your tasks for this week.</p>
                                </div>
                                <div class="congratulation-img">
                                    <img src="assets/img/media/congratulation-img.png" alt="">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Card -->
                </div>

                
            </div>
            
        </div>
    </div>


    <!-- End Main Content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\augmedix\resources\views/dashboard.blade.php ENDPATH**/ ?>