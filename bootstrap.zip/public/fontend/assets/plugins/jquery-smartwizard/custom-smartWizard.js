/*---------------------------------------------
Template name :  Dashmin
Version       :  1.0
Author        :  ThemeLooks
Author url    :  http://themelooks.com


** Custom SmartWizard JS

----------------------------------------------*/

$('#smartwizard').smartWizard({
    theme: 'arrows'
});


$('#smartwizard2').smartWizard();


